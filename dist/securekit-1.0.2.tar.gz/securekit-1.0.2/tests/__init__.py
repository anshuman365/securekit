"""
Test suite for securekit
"""