"""
Command-line interface for securekit
"""